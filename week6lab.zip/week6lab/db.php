<?php
 
$servername = "lrgs.ftsm.ukm.my";
$username = "a177016";
$password = "tinyblacktiger";
$dbname = "a177016";
 
?>